const applicationId = process.env.DISCORD_APPLICATION_ID;
const botToken = process.env.DISCORD_BOT_TOKEN;
const guildId = process.env.DISCORD_GUILD_ID;

if (!applicationId) {
  throw new Error("Missing DISCORD_APPLICATION_ID");
}

if (!botToken) {
  throw new Error("Missing DISCORD_BOT_TOKEN");
}

const commands = [
  {
    name: "todo",
    description: "Todo を追加する",
    type: 1,
    options: [
      {
        name: "text",
        description: "タスク本文",
        type: 3,
        required: true
      }
    ]
  },
  {
    name: "todo-list",
    description: "Todo 一覧を表示する",
    type: 1,
    options: [
      {
        name: "status",
        description: "open, done, all から選ぶ",
        type: 3,
        required: false,
        choices: [
          { name: "open", value: "open" },
          { name: "done", value: "done" },
          { name: "all", value: "all" }
        ]
      }
    ]
  },
  {
    name: "todo-done",
    description: "Todo を完了にする",
    type: 1,
    options: [
      {
        name: "id",
        description: "完了にしたい Todo ID",
        type: 4,
        required: true
      }
    ]
  },
  {
    name: "info",
    description: "固定情報のリンクを返す",
    type: 1,
    options: [
      {
        name: "topic",
        description: "外泊, ダイビング, ジム など",
        type: 3,
        required: true
      }
    ]
  }
];

const apiBase = "https://discord.com/api/v10";
const url = guildId
  ? `${apiBase}/applications/${applicationId}/guilds/${guildId}/commands`
  : `${apiBase}/applications/${applicationId}/commands`;

const response = await fetch(url, {
  method: "PUT",
  headers: {
    Authorization: `Bot ${botToken}`,
    "Content-Type": "application/json"
  },
  body: JSON.stringify(commands)
});

if (!response.ok) {
  const text = await response.text();
  throw new Error(`Command registration failed: ${response.status} ${text}`);
}

const data = await response.json();
console.log(`Registered ${data.length} command(s) to ${guildId ? "guild" : "global"} scope.`);
